using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SwichtLogic : MonoBehaviour
{
    new public BoxCollider2D collider2D;
    public BoxCollider2D othercollider2D;
    public GameObject blocks;
    public GameObject otherBlocks;
    public Sprite pressedSprite;
    public Sprite otherReleasedSprite;
    public SpriteRenderer mySwitch;
    public SpriteRenderer otherSwitch;
    // Start is called before the first frame update
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            blocks.SetActive(true);
            otherBlocks.SetActive(false);
            mySwitch.sprite = pressedSprite;
            otherSwitch.sprite = otherReleasedSprite;
            collider2D.enabled = false;
            othercollider2D.enabled = true;
        }
    }
}
