using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class TimeManager : MonoBehaviour
{
    private float time = 400;
    [SerializeField] private TMP_Text timeText;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        time -= Time.deltaTime;
        timeText.text = "Time: " + (int)time;

        if(time <= 0)
        {
            Died();
        }
    }
    public static void Died()
    {
        SceneManager.LoadScene(1);
    }
}
