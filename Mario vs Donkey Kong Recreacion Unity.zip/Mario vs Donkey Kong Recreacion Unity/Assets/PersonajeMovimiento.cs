using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PersonajeMovimiento : MonoBehaviour
{
    [SerializeField] private float speed;
    [SerializeField] private float jumpForce;
    private Rigidbody2D rig;
    private Animator animator;
    private SpriteRenderer sr;
    bool isJumping;
    private void Awake()
    {
        rig = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        sr = GetComponent<SpriteRenderer>();
    }
    private void FixedUpdate()
    {
        float horizontal = Input.GetAxis("Horizontal");
        Vector2 vel = new Vector2(0, rig.velocity.y);
        horizontal *= speed;
        vel.x = horizontal;
        rig.velocity = vel;
        animator.SetFloat("Speed", Mathf.Abs(rig.velocity.magnitude));
        if(horizontal > 0)
        {
            
            sr.flipX = false;
        }
        else if(horizontal < 0)
        {
            
            sr.flipX = true;
        }
    }
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space) && isJumping == false)
        {
            rig.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
            
        }
        
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("ground"))
        {
            animator.SetBool("Jump", false);
            isJumping = false;
        }
        
    }
    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("ground"))
        {
            animator.SetBool("Jump", true);
            isJumping = true;
        }
    }

}
